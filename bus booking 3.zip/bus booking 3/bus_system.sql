-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 01, 2022 at 09:58 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bus_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `massage` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`name`, `email`, `massage`) VALUES
('hufguy', 'yyt@gmail.com', 'tyy'),
('hufguy', 'yyt@gmail.com', 'tyy'),
('yusufuguudffu', 'yuy#@gmail.com', 'ghhghghgdg'),
('eyuedyyu', 'ythg@gmail.com', 'ythdhdghd'),
('ydufgfjhdhf', 'tyysdd@gmail.com', 'yyusdhdhgd'),
('', '', ''),
('uyy', 'yyy@gmail.com', 'tyyyuihdfghjcf');

-- --------------------------------------------------------

--
-- Table structure for table `form`
--

CREATE TABLE `form` (
  `cname` varchar(20) NOT NULL,
  `cwebsite` varchar(30) NOT NULL,
  `cemail` varchar(30) NOT NULL,
  `caddress` varchar(20) NOT NULL,
  `cowner` varchar(30) NOT NULL,
  `cdes` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `form`
--

INSERT INTO `form` (`cname`, `cwebsite`, `cemail`, `caddress`, `cowner`, `cdes`) VALUES
('', 'www.deltaexpress.com', 'delta@gmail.com', 'delta@gmail.com', 'yusuf abubakar', 'is i good company'),
('delt', '', '', '', '', ''),
('delta express kano', 'www.deltaexpress.com', 'delta@gmail.com', 'delta@gmail.com', 'yusuf abubakar', 'this is the best company'),
('hueryueru', 'yty', 'tyt@gmail.com', 'tydyfyd', 'ytgfdtyd', 'gydhhudhd'),
('jaon', 'wef', 'we@gmail.com', 'wef', 'dfgh', 'sfgf');

-- --------------------------------------------------------

--
-- Table structure for table `landstar`
--

CREATE TABLE `landstar` (
  `busid` int(20) NOT NULL,
  `day` varchar(20) NOT NULL,
  `from` varchar(20) NOT NULL,
  `to` varchar(20) NOT NULL,
  `depature` text NOT NULL,
  `arrived` text NOT NULL,
  `price` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `landstar`
--

INSERT INTO `landstar` (`busid`, `day`, `from`, `to`, `depature`, `arrived`, `price`) VALUES
(333, 'moday', 'kano', 'lagos', '12:00pm', '6:00am', '12,500'),
(333, 'moday', 'kano', 'lagos', '12:00pm', '6:00am', '12,500');

-- --------------------------------------------------------

--
-- Table structure for table `table1`
--

CREATE TABLE `table1` (
  `busname` varchar(20) NOT NULL,
  `busid` varchar(29) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `table1`
--

INSERT INTO `table1` (`busname`, `busid`) VALUES
('bus', '123'),
('bus', '555'),
('532532', '376347'),
('[value-1]', '[value-2]'),
('23223', 'ydhsdh'),
('55', 'ghhgh'),
('yusuf', '456'),
('yuugf', '45678');

-- --------------------------------------------------------

--
-- Table structure for table `table3`
--

CREATE TABLE `table3` (
  `busid` int(5) NOT NULL,
  `day` varchar(20) NOT NULL,
  `from` varchar(20) NOT NULL,
  `to` varchar(20) NOT NULL,
  `depature` text NOT NULL,
  `arrived` text NOT NULL,
  `price` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `table3`
--

INSERT INTO `table3` (`busid`, `day`, `from`, `to`, `depature`, `arrived`, `price`) VALUES
(333, 'moday', 'kano', 'lagos', '12', '6:00am', '12'),
(333, 'moday', 'kano', 'lagos', '12', '6:00am', '12');

-- --------------------------------------------------------

--
-- Table structure for table `table4`
--

CREATE TABLE `table4` (
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `seat` int(30) NOT NULL,
  `reference` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `table4`
--

INSERT INTO `table4` (`name`, `email`, `seat`, `reference`) VALUES
('yusuf', 'y@gmail.com', 1883, 4334),
('yusuf', '28384', 123, 4334),
('234', '2345', 445, 4334),
('234567', 'WEDRFTY', 56, 4334),
('FTGQ', 'ERTGH', 234, 4334),
('1234RT', '123', 2, 4334),
('213456', '45678', 3456789, 12345678),
('345678', 'qwertyuio', 23456, 12345678),
('', '', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(20) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `userid` varchar(200) NOT NULL,
  `password` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `contact` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `fname`, `lname`, `userid`, `password`, `email`, `contact`) VALUES
(1400, 'trtr', 'erre', '144', '144', 'h@gmail.com', '23456'),
(1511, 'yusuf', 'abubakar', '0813', '08133106937', 'yusufabubakar305@gma', '08133106937'),
(1513, 'trtr', 'erre', '144', '144', 'h@gmail.com', '23456'),
(1514, 'trtr', 'erre', '144', '144', 'h@gmail.com', '23456'),
(1515, 'trtr', 'erre', '144', '144', 'h@gmail.com', '23456'),
(1516, 'habu', 'habu', '8888', '888888', 'habu@gmail.com', '04968658'),
(1517, 'habu', 'habu', '8888', '888888', 'habu@gmail.com', '04968658'),
(1518, 'habu', 'habu', '8888', '888888', 'habu@gmail.com', '04968658'),
(1519, 'habu', 'habu', '8888', '888888', 'habu@gmail.com', '04968658'),
(1520, 'habu', 'habu', '8888', '888888', 'habu@gmail.com', '04968658'),
(1521, 'habu', 'habu', '8888', '888888', 'habu@gmail.com', '04968658'),
(1522, 'habu', 'habu', '8888', '888888', 'habu@gmail.com', '04968658'),
(1523, 'habu', 'habu', '8888', '888888', 'habu@gmail.com', '04968658'),
(1524, 'habu', 'habu', '44', '888888', 'habu@gmail.com', '04968658'),
(1525, 'habu', 'habu', '44', '888888', 'habu@gmail.com', '04968658'),
(1526, 'habu', 'habu', '44', '888888', 'habu@gmail.com', '04968658'),
(1527, 'edf', 'wsdf', '123', '2', 'ee@gmail.com', 'wedfgh21');

-- --------------------------------------------------------

--
-- Table structure for table `welfare`
--

CREATE TABLE `welfare` (
  `busid` int(20) NOT NULL,
  `day` varchar(20) NOT NULL,
  `from` varchar(20) NOT NULL,
  `to` varchar(20) NOT NULL,
  `depature` text NOT NULL,
  `arrived` text NOT NULL,
  `price` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `welfare`
--

INSERT INTO `welfare` (`busid`, `day`, `from`, `to`, `depature`, `arrived`, `price`) VALUES
(333, 'moday', 'kano', 'lagos', '12:00pm', '6:00am', '12,500'),
(333, 'moday', 'kano', 'lagos', '12:00pm', '6:00am', '12,500');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `form`
--
ALTER TABLE `form`
  ADD PRIMARY KEY (`cname`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1528;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
