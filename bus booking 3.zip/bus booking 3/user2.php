<?php


 // database connection code // 
 
 $con = mysqli_connect('localhost', 'root','' ,'bus_system');
 
 // get the post records //
 $fname = $_POST['fname'];
 $lname = $_POST['lname']; 
 $userid = $_POST['userid']; 
 $password = $_POST['password']; 
  $email = $_POST['email'];
    $contact= $_POST['contact'];
 // database insert SQL code 
 $sql = "INSERT INTO `user` (
 `fname`, `lname`, `userid`,
 `password`, `email`,`contact`) VALUES ( '$fname', 
 '$lname', '$userid',
 '$password','$email','$contact')";
 // insert in database

 $rs = mysqli_query($con, $sql);
 if($rs) { 
 echo "Contact Records Inserted";
 header('location:login3.php');
 }  
 ?>
 