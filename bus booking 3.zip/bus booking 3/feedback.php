<?php


 // database connection code // 
 
 $con = mysqli_connect('localhost', 'root','' ,'bus_system');
 
 // get the post records //
 $name = $_POST['name'];
 
 $email= $_POST['email']; 
 $massage = $_POST['massage']; 
 
  
 // database insert SQL code 
 $sql = "INSERT INTO `feedback` ( `name`, `email`, `massage`) VALUES ( '$name', '$email','$massage')";
 // insert in database

 $rs = mysqli_query($con, $sql);
 if($rs) { 

 echo'<script type="text/javescript">';
 echo'alert("javascript")';
 echo'</script>';
header('location:fd.html');
 }  
 ?>
 