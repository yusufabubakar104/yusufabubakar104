<?php


 // database connection code // 
 
 $con = mysqli_connect('localhost', 'root','' ,'bus_system');
 
 // get the post records //
 $busid = $_POST['busid'];
 $day = $_POST['day']; 
 $from= $_POST['from'];
$to= $_POST['to']; 
 $depature = $_POST['depature']; 
  $arrived = $_POST['arrived'];
    $price= $_POST['price'];
 // database insert SQL code 
 $sql1 = "INSERT INTO `table3` (
 `busid`, `day`, `from`,
 `to`, `depature`,`arrived`,`price`) VALUES ( '$busid', 
 
 '$day','$from','$to','$depature','$arrived','$price')";
  $sql2 = "INSERT INTO `welfare` (
 `busid`, `day`, `from`,
 `to`, `depature`,`arrived`,`price`) VALUES ( '$busid', 
 
 '$day','$from','$to','$depature','$arrived','$price')";
  $sql3 = "INSERT INTO `landstar` (
 `busid`, `day`, `from`,
 `to`, `depature`,`arrived`,`price`) VALUES ( '$busid', 
 
 '$day','$from','$to','$depature','$arrived','$price')";
 // insert in database

 $rs = mysqli_query($con, $sql1);
  $rs = mysqli_query($con, $sql2);
   $rs = mysqli_query($con, $sql3);
 if($rs) { 
 echo "Contact Records Inserted";
 
 }  
 ?>
 