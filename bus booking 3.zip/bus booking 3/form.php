<?php


 // database connection code // 
 
 $con = mysqli_connect('localhost', 'root','' ,'bus_system');
 
 // get the post records //
 $cname = $_POST['cname'];
 $cwebsite = $_POST['cwebsite']; 
 $cemail= $_POST['cemail']; 
 $caddress = $_POST['caddress']; 
  $cowner = $_POST['cowner'];
    $cdes= $_POST['cdes'];
 // database insert SQL code 
 $sql = "INSERT INTO `form` (
 `cname`, `cwebsite`, `cemail`,
 `caddress`, `cowner`,`cdes`) VALUES ( '$cname', 
 
 '$cwebsite','$cemail','$caddress','$cowner','$cdes')";
 // insert in database

 $rs = mysqli_query($con, $sql);
 if($rs) { 
 echo "Contact Records Inserted";
 header('location:form.html');
 }  
 ?>
 