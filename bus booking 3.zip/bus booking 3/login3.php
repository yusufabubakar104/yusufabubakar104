<!DOCTYPE html>
<html>
<head>
<title>login</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="assets/css/login.css">
 </head>
<body>

 <script src="jquery-1.10.2.min.js"></script>
    <script>
      
          
            
    </script>
	
<section id="form">
        <center>
            <table border="0" cellspacing="15px">
            <form  method="post" action="login5.php">
                <tr>
                    <td colspan="4">
                        <a href="login.html"><input type="button" id="signin" value="SIGN IN"/></a>
                        <a href="signup.html"><input type="button" id="signup" value="SIGN UP"/></a>
                    </td>
                </tr>
              
                <tr>
                    <td colspan="4">
                        <div id="uid">
                            <input type="text" placeholder="USER ID"name="userid" id="userid" required>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td colspan="4">
                        <div id="pass">
                            <input type="password" placeholder="PASSWORD"name="password" id="password"required>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td colspan="4">
                        <div id="login">
                            <input type="submit" value="submit"name="Submit" id="Submit">
                        </div>
                    </td>
                </tr>
                <tr>
                    <td colspan="4" align="right">
                        <div id="fp">
                            <a href="forgot%20password.html">Forgot Password?</a>
                        </div>
                    </td>
                </tr>
            </form>
            </table>
        </center>
        </section>

</body>
</html>

